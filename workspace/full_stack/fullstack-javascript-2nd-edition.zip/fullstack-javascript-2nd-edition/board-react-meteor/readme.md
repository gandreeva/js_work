To use your existing MongoDB database (name board in this example):

```
$ MONGO_URL=mongodb://localhost:27017/board meteor
```
