({
    appDir: "./js",
    baseUrl: "./",
    dir: "build",
    optimize: "uglify",
    modules: [
        {
            name: "apple-app"
        }
    ]
})