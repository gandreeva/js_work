define(function(){
  return '<img src="img/spinner.gif" width="30"/>';
});