var appleTpl = '<figure>\
                  <img src="<%= attributes.url%>"/>\
                  <figcaption><%= attributes.name %></figcaption>\
                </figure>'
