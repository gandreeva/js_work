```
$ npm install -g babel
$ babel -w ./js/app.jsx -o ./js/app.js
```